<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Form Submission</title>
</head>
<body>
    <h2>New Form Submission</h2>
    <p>Thank you for your submission!</p>

    <h3>Details:</h3>
    <ul>
        <li><strong>Name:</strong> {{ $data['name'] }}</li>
        <li><strong>Email:</strong> {{ $data['email'] }}</li>
        <li><strong>Message:</strong> {{ $data['message'] }}</li>
    </ul>

    <p>You'll receive a confirmation email shortly. We'll get back to you as soon as possible.</p>

    <p>Best regards,<br>
    <p>Your Company Name</p>
</body>
</html>
